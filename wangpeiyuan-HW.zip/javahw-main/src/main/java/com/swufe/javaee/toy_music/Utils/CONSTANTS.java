package com.swufe.javaee.toy_music.Utils;

/**
 * Constants, such as admin email, password.
 *
 * Hint: What about putting them into web.xml as Parameters?
 */
public class CONSTANTS {
    public final static String ADMIN_EMAIL = "admin@music.com";
    public final static String ADMIN_PWD = "swufe123";
    // for Windows, it can be something like: C:\\User\\yourname\\Desktop\\music.txt
    public final static String SONG_FILE = "C:\\Users\\15726\\Desktop\\music.txt";

    public final static int TOP_K = 2;
}
